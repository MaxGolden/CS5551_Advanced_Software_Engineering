package tutorial.cs5551.com.translateapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

//AppCompatActivity:
public class CheckLcode extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check_code);
    }

    public void checkcodeb(View v) {
        Intent redirect = new Intent(CheckLcode.this, TranslateActivity.class);
        startActivity(redirect);
    }
}
